﻿// Decompiled with JetBrains decompiler
// Type: UL_PROCESSOR.PersonInfo
// Assembly: UL_PROCESSOR, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F5FBFFAF-2271-40AA-9C8E-13AEE0DF74F3
// Assembly location: C:\Users\Psychology\Documents\Visual Studio 2015\Projects\UL_PROCESSOR\UL_PROCESSOR\bin\Debug\UL_PROCESSOR.exe

using System;

namespace UL_PROCESSOR
{
  public class PersonInfo
  {
    public DateTime startTime = new DateTime();
    public bool startTimeSet = false;
    public string ubiId = "";
    public string lenaId = "";
    public string bid = "";
    public DateTime dt = new DateTime();
    public bool wasTalking = false;
    public double x = 0.0;
    public double y = 0.0;
    public double z = 0.0;
    public double ori = 0.0;
    public double ori2 = 0.0;
    public double vd = 0.0;
    public double vc = 0.0;
    public double tc = 0.0;
    public double bd = 0.0;
    public double no = 0.0;
    public double ac = 0.0;
    public double oln = 0.0;
    public double cry = 0.0;
    public double lx = 0.0;
    public double ly = 0.0;
    public double rx = 0.0;
    public double ry = 0.0;
    public bool isFreePlay = false;
    public bool isCrying = false;
        public double avDb = 0;
        public double maxDb = 0;
        public double childSegments = 0;

        public double individualTime = 0;
        public double interactionTime = 0;
        public double cryingTime = 0;


        public String szLineData = "";
        public String tagType = "";
        public String tag = "";

    }
}

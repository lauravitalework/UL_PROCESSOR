﻿// Decompiled with JetBrains decompiler
// Type: UL_PROCESSOR.Interactions
// Assembly: UL_PROCESSOR, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F5FBFFAF-2271-40AA-9C8E-13AEE0DF74F3
// Assembly location: C:\Users\Psychology\Documents\Visual Studio 2015\Projects\UL_PROCESSOR\UL_PROCESSOR\bin\Debug\UL_PROCESSOR.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace UL_PROCESSOR
{
  internal class Interactions
  {
     
  }
}

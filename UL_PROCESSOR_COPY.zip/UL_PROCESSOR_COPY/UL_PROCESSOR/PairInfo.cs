﻿// Decompiled with JetBrains decompiler
// Type: UL_PROCESSOR.PairInfo
// Assembly: UL_PROCESSOR, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F5FBFFAF-2271-40AA-9C8E-13AEE0DF74F3
// Assembly location: C:\Users\Psychology\Documents\Visual Studio 2015\Projects\UL_PROCESSOR\UL_PROCESSOR\bin\Debug\UL_PROCESSOR.exe

namespace UL_PROCESSOR
{
  public class PairInfo
  {
    public string szSubject = "";
    public string szPartner = "";
    public PersonInfo p1 = new PersonInfo();
    public PersonInfo p2 = new PersonInfo();
    public PersonInfo subject = new PersonInfo();
    public PersonInfo partner = new PersonInfo();
    public double sharedTimeInSecs = 0.0;
    public double closeTimeInSecs = 0.0;
    public double closeAndOrientedTimeInSecs = 0.0;
    public double closeAndOrientedCryInSecs = 0.0;
    public double closeTalkingTimeInSecs = 0.0;
        public double closeAndOrientedTalkInSecs = 0.0;
        public double closeVDTimeInSecs = 0.0;
        public double closeAndOrienteVDInSecs = 0.0;

        public bool subjectSet = false;
        public bool partnerSet = false;


    }
}

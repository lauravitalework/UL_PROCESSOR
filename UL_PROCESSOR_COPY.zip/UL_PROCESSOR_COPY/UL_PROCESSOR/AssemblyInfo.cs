﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("UL_PROCESSOR")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("UL_PROCESSOR")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("ed7b4497-3ff9-4d94-aa9e-e26b05dceae3")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
